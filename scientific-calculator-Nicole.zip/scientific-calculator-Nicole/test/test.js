
const { sqrt, checkNum, addChar } = require('../src/script');


const assert = require('assert');

describe('squareRoot function', () => {
    describe('first test', () => {
        it('should output the value of the square root of a positive number',()=>{
            var result =  { display: { value: 9 } };
            sqrt(result)
            assert.equal(result.display.value, 3)
        })        
    })

    describe('second test', () => {
        it('should output the value of the square root of a decimal number',()=>{
            var result =  { display: { value: 12.25  } };
            sqrt(result)
            assert.equal(result.display.value, 3.5)
        })        
    })

    describe('third test', () => {
        it('should output Nan as the square root of a negative number',()=>{
            var result =  { display: { value: -9 } };
            sqrt(result)
            assert.equal(result.display.value, NaN)
        })
    })

});

describe('checkNum function', () => {
    describe('first test', () => {
        it('should return true for valid characters', () => {
            var result = checkNum('2938');
            assert.equal(result, true);
        });
        
    });   
    describe('second test', () => {
        it('should return false for invalid characters', () => {
            var result = checkNum('!@#AbC');
            assert.equal(result, false);
        });
        
    });

    describe('third test', () => {
        it('should return false for a mixture of valid and invalid characters', () => {
            var result = checkNum('!6@7A#8b');
            assert.equal(result, false);
        })
    })

});

describe('addChar function', () => {

    describe('first test', () => {
        it('should add a digit to the empty input', () => {
            var input = { value: '' };
            addChar(input, '5');
            assert.equal(input.value, '5');
        });
    })

    describe('second test', () => {
        it('should add a digit to the existing input', () =>{
            var input = { value: '8723' };
            addChar(input, '4');
            assert.equal(input.value, '87234');
          });
    })

    describe('third test', () => {
        it('should add a decimal point to the existing input',  () => {
            var input = { value: '6' };
            addChar(input, '.');
            assert.equal(input.value, '6.');
          });
    })

});


